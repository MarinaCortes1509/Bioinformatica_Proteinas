import streamlit as st
from collections import Counter
import matplotlib.pyplot as plt

# Título de la aplicación
st.title("Análisis de Secuencias de Proteínas")

# Descripción breve
st.write("""
Esta aplicación permite cargar y analizar secuencias de proteínas en formato FASTA. 
Puedes obtener un desglose de la composición de aminoácidos.
""")

# Carga de archivo FASTA
uploaded_file = st.file_uploader("Carga un archivo FASTA", type=["fasta", "txt"])

# Diccionario de pesos moleculares aproximados de los aminoácidos
amino_acid_weights = {
    'A': 89.09, 'R': 174.20, 'N': 132.12, 'D': 133.10, 'C': 121.15,
    'E': 147.13, 'Q': 146.15, 'G': 75.07, 'H': 155.16, 'I': 131.17,
    'L': 131.17, 'K': 146.19, 'M': 149.21, 'F': 165.19, 'P': 115.13,
    'S': 105.09, 'T': 119.12, 'W': 204.23, 'Y': 181.19, 'V': 117.15
}

# Procesar el archivo cargado
if uploaded_file:
    fasta_data = uploaded_file.read().decode("utf-8").splitlines()
    
    # Filtrar solo las secuencias
    sequences = [line.strip() for line in fasta_data if not line.startswith(">")]
    protein_sequence = "".join(sequences)  # Combinar todas las líneas en una sola secuencia

    # Mostrar la secuencia
    st.subheader("Secuencia cargada:")
    st.code(protein_sequence)

    # Contar la frecuencia de cada aminoácido
    amino_acid_counts = Counter(protein_sequence)

    # Mostrar la composición
    st.subheader("Composición de aminoácidos:")
    st.write(amino_acid_counts)

    # Calcular peso molecular aproximado
    molecular_weight = sum(amino_acid_weights.get(aa, 0) * count for aa, count in amino_acid_counts.items())
    st.write(f"Peso molecular aproximado: {molecular_weight:.2f} Da")

    # Crear gráfico de barras para la composición de aminoácidos
    st.subheader("Gráfico de composición de aminoácidos:")
    fig, ax = plt.subplots()
    ax.bar(amino_acid_counts.keys(), amino_acid_counts.values(), color='skyblue')
    ax.set_xlabel("Aminoácidos")
    ax.set_ylabel("Frecuencia")
    ax.set_title("Composición de aminoácidos")
    st.pyplot(fig)
else:
    st.info("Por favor, carga un archivo FASTA para comenzar el análisis.")

